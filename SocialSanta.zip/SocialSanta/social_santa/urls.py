# from django.urls import path
# from . import views

# urlpatterns = [
#     path('', views.home, name='home'),
# ]

from django.urls import path
from .views import youtube_stats
from .views import index
from .views import service

urlpatterns = [
    path('', index, name=''),
    path('services', service, name=''),
    path('youtube_status', youtube_stats, name=''),
]