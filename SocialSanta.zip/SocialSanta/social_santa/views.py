# from django.shortcuts import render

# def home(request):
#     return render(request, 'home.html')

import requests
from django.shortcuts import render
from django.conf import settings

# Replace with your actual YouTube Channel ID
# CHANNEL_ID = "UC_x5XG1OV2P6uZZ5FSM9Ttw"
# API_KEY = "YOUR_YOUTUBE_API_KEY"

API_KEY = "AIzaSyB0mzwrOieSbT4rrUEZ_olCeKRh7Xu83d8"
CHANNEL_ID = "UCb7ZGkh3BgYqNn82yzuVVmw"


def get_youtube_data():
    # Fetch subscriber count
    url = f"https://www.googleapis.com/youtube/v3/channels?part=statistics&id={CHANNEL_ID}&key={API_KEY}"
    response = requests.get(url)
    data = response.json()

    subscriber_count = "N/A"
    latest_video = "No video found"

    if "items" in data and len(data["items"]) > 0:
        subscriber_count = data["items"][0]["statistics"]["subscriberCount"]

    # Fetch latest video
    video_url = f"https://www.googleapis.com/youtube/v3/search?part=snippet&channelId={CHANNEL_ID}&maxResults=1&order=date&type=video&key={API_KEY}"
    video_response = requests.get(video_url)
    video_data = video_response.json()

    if "items" in video_data and len(video_data["items"]) > 0:  # Check if "items" exists and is not empty
        latest_video = video_data["items"][0]["snippet"]["title"]

    return {
        "subscribers": subscriber_count,
        "latest_video": latest_video
    }

def youtube_stats(request):
    stats = get_youtube_data()
    return render(request, 'youtube.html', {"stats": stats})

def index(request):
    return render(request, 'home.html')

def service(request):
    return render(request, 'service.html')